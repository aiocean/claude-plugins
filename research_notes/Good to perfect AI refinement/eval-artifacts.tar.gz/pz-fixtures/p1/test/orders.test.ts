import { expect, test } from "bun:test";
import { formatCents, lineTotal, orderSubtotal, orderTotal, totalsByCustomer, type Order } from "../src/orders";

const order: Order = {
  id: "o1",
  customer: "ada",
  lines: [
    { sku: "a", qty: 2, unitCents: 1000 },
    { sku: "b", qty: 1, unitCents: 500 },
  ],
};

test("lineTotal multiplies qty by unit price", () => {
  expect(lineTotal({ sku: "a", qty: 3, unitCents: 250 })).toBe(750);
});

test("orderSubtotal sums lines", () => {
  expect(orderSubtotal(order)).toBe(2500);
});

test("orderTotal adds 8% tax by default", () => {
  expect(orderTotal(order)).toBe(2700);
});

test("orderTotal can skip tax", () => {
  expect(orderTotal(order, false)).toBe(2500);
});

test("SAVE10 takes 10% off before tax", () => {
  expect(orderTotal({ ...order, coupon: "SAVE10" }, false)).toBe(2250);
});

test("FLAT5 takes 500 cents off", () => {
  expect(orderTotal({ ...order, coupon: "FLAT5" }, false)).toBe(2000);
});

test("totalsByCustomer groups orders", () => {
  const totals = totalsByCustomer([order, { ...order, id: "o2" }]);
  expect(totals).toEqual({ ada: 5400 });
});

test("formatCents formats dollars", () => {
  expect(formatCents(2500)).toBe("$25.00");
});
