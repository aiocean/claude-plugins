import { expect, test } from "bun:test";
import { LRUCache } from "../src/lru";

test("set on an existing key refreshes it and updates the value", () => {
  const c = new LRUCache<string, number>(2);
  c.set("a", 1);
  c.set("b", 2);
  c.set("a", 10);
  c.set("c", 3);
  expect(c.get("a")).toBe(10);
  expect(c.has("b")).toBe(false);
});

test("has does not refresh recency", () => {
  const c = new LRUCache<string, number>(2);
  c.set("a", 1);
  c.set("b", 2);
  c.has("a");
  c.set("c", 3);
  expect(c.has("a")).toBe(false);
});

test("delete removes and reports", () => {
  const c = new LRUCache<string, number>(2);
  c.set("a", 1);
  expect(c.delete("a")).toBe(true);
  expect(c.delete("a")).toBe(false);
  expect(c.size).toBe(0);
});

test("capacity 1 keeps only the latest entry", () => {
  const c = new LRUCache<string, number>(1);
  c.set("a", 1);
  c.set("b", 2);
  expect(c.has("a")).toBe(false);
  expect(c.get("b")).toBe(2);
});

test("undefined-valued entries still count as present", () => {
  const c = new LRUCache<string, undefined>(2);
  c.set("a", undefined);
  expect(c.has("a")).toBe(true);
  expect(c.size).toBe(1);
});

test("rejects non-integer and negative capacity", () => {
  expect(() => new LRUCache(1.5)).toThrow(RangeError);
  expect(() => new LRUCache(-1)).toThrow(RangeError);
});
