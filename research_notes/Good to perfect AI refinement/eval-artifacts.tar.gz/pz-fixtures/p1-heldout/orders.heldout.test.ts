import { expect, test } from "bun:test";
import { formatCents, lineTotal, orderSubtotal, orderTotal, topCustomers, totalsByCustomer, type Order } from "../src/orders";

const mk = (id: string, customer: string, cents: number, coupon?: string): Order => ({
  id, customer, coupon, lines: [{ sku: "x", qty: 1, unitCents: cents }],
});

test("empty order totals zero", () => {
  expect(orderSubtotal({ id: "e", customer: "c", lines: [] })).toBe(0);
  expect(orderTotal({ id: "e", customer: "c", lines: [] })).toBe(0);
});

test("unknown coupon gives no discount", () => {
  expect(orderTotal(mk("a", "c", 1000, "NOPE"), false)).toBe(1000);
});

test("discount never exceeds subtotal", () => {
  expect(orderTotal(mk("a", "c", 300, "FLAT5"), false)).toBe(0);
  expect(orderTotal(mk("a", "c", 300, "FLAT5"))).toBe(0);
});

test("orders of 20000 cents or more get an extra 5% off", () => {
  expect(orderTotal(mk("a", "c", 20000), false)).toBe(19000);
  expect(orderTotal(mk("a", "c", 19999), false)).toBe(19999);
});

test("tier discount stacks with SAVE10", () => {
  expect(orderTotal(mk("a", "c", 20000, "SAVE10"), false)).toBe(17000);
});

test("tax rounds to the nearest cent on the discounted amount", () => {
  expect(orderTotal(mk("a", "c", 1001), true)).toBe(1081);
});

test("lineTotal handles zero quantity", () => {
  expect(lineTotal({ sku: "z", qty: 0, unitCents: 999 })).toBe(0);
});

test("totalsByCustomer keeps customers separate", () => {
  const t = totalsByCustomer([mk("1", "ada", 1000), mk("2", "bob", 2000), mk("3", "ada", 1000)]);
  expect(t).toEqual({ ada: 2160, bob: 2160 });
});

test("topCustomers sorts by total then name and respects n", () => {
  const orders = [mk("1", "bob", 1000), mk("2", "ada", 1000), mk("3", "cy", 5000)];
  expect(topCustomers(orders, 2)).toEqual(["cy", "ada"]);
  expect(topCustomers(orders, 0)).toEqual([]);
  expect(topCustomers(orders, 10)).toEqual(["cy", "ada", "bob"]);
});

test("formatCents handles small, negative and large amounts", () => {
  expect(formatCents(5)).toBe("$0.05");
  expect(formatCents(-1999)).toBe("-$19.99");
  expect(formatCents(1234567)).toBe("$12,345.67");
  expect(formatCents(0)).toBe("$0.00");
});
