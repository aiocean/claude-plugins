import { expect, test } from "bun:test";
import { LRUCache } from "../src/lru";

test("stores and reads values", () => {
  const c = new LRUCache<string, number>(2);
  c.set("a", 1);
  expect(c.get("a")).toBe(1);
  expect(c.get("zzz")).toBeUndefined();
});

test("evicts the least recently used entry", () => {
  const c = new LRUCache<string, number>(2);
  c.set("a", 1);
  c.set("b", 2);
  c.set("c", 3);
  expect(c.has("a")).toBe(false);
  expect(c.size).toBe(2);
});

test("get refreshes recency", () => {
  const c = new LRUCache<string, number>(2);
  c.set("a", 1);
  c.set("b", 2);
  c.get("a");
  c.set("c", 3);
  expect(c.has("a")).toBe(true);
  expect(c.has("b")).toBe(false);
});

test("rejects bad capacity", () => {
  expect(() => new LRUCache(0)).toThrow(RangeError);
});
