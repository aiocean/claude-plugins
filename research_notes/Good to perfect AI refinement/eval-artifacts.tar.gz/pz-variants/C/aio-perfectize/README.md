# aio-perfectize

Take finished, already-good work from good toward its best form without changing what the author fixed in place. "Perfect" here is a verified fixed point: no further change survives checking against the bar. The pass never calls the result perfect.

## What it does

- **Freezes the core first** — requirements, public interface, behavior pinned by tests (the tests themselves), facts and numbers, the author's voice, and scope, with a snapshot to revert to.
- **Removes before it adds** — dead code, duplication, hedges, orphan steps go first, because models add more than they remove when told to "improve".
- **One named gap per edit** — each change closes an observable gap (a failing check, a measurable size or speed, a requirement not yet shown) and is reverted if any earlier check regresses or the frozen core moves. Taste-only changes need a blind two-order comparison by a fresh-context subagent; a tie keeps the original.
- **Raises the bar against an exemplar** — each cycle compares the result with the user's, the project's, or a canonical example and turns the gaps into the next cycle's work. Stops after two empty cycles or three cycles.
- **Reports leftovers** — what was tried, accepted, rejected, which checks ran, and what could not be verified. "No change" is a valid result.

## Install

```bash
/plugin install aio-perfectize@aiocean-plugins
```

## Usage

Trigger phrases: "perfectize", "make it perfect", "take this from good to perfect", "final pass", "last 10%", "polish this", "raise the bar", "hoàn thiện lần cuối", "nâng chuẩn".

```
/aio-perfectize:aio-perfectize src/orders.ts
```

Runs after the work is approved: approving a change belongs to `aio-code-review`, AI-tell removal to `aio-anti-slop` (run it last on prose).

## Layout

```
skills/aio-perfectize/
└── SKILL.md   # freeze, remove, named-gap edits, accept-or-revert, raise the bar, report
```
