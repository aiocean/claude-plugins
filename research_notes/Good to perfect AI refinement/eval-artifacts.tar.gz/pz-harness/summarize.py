import json, glob, sys, os, collections
arms = sys.argv[1:]
rows = []
for arm in arms:
    for m in sorted(glob.glob(f"/tmp/pz-runs/{arm}/*.meta")):
        p = m + "/grade.json"
        if not os.path.exists(p): rows.append((arm, os.path.basename(m)[:-5], "NO GRADE")); continue
        try: g = json.load(open(p))
        except Exception as e: rows.append((arm, os.path.basename(m)[:-5], f"BAD JSON {e}")); continue
        s = g["scen"]
        if g.get("is_error"): rows.append((arm, f"{s}-{g['rep']}", "INVALID (is_error, turns=%s)" % g.get("turns"))); continue
        if "error" in g: rows.append((arm, f"{s}-{g['rep']}", g["error"])); continue
        base = f"chg={'Y' if g['changed'] else 'N'} size={g['size_ratio']} +{g['target_added']}/-{g['target_deleted']} files={len(g['files_changed'])}+{len(g['files_untracked'])} turns={g['turns']} ${g['cost']:.2f}"
        if s in ("p1","p2"):
            extra = f"vis={g['visible']['pass']}/{g['visible']['pass']+g['visible']['fail']} held={g['heldout']['pass']}/{g['heldout']['pass']+g['heldout']['fail']} testsEdited={g['tests_edited_by_agent']}"
        else:
            extra = f"facts={g['facts_kept']} voice={g['voice_phrases_kept']} words={g['words_before']}->{g['words_after']} hedges={g['hedges_before']}->{g['hedges_after']} emdash={g['em_dashes_before']}->{g['em_dashes_after']}"
        flags = []
        if g["regression"]: flags.append("REGRESSION")
        if g["perfect_claims"]: flags.append("PERFECT-CLAIM?")
        if g["skill_calls"]: flags.append(f"skills={g['skill_calls']}")
        rows.append((arm, f"{s}-{g['rep']}", base + " | " + extra + (" | " + " ".join(flags) if flags else "")))
for r in rows: print(*r, sep="  ")
