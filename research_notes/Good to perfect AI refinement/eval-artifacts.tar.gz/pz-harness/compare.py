import json, glob, collections, statistics, sys
def load(arm):
    out = collections.defaultdict(list)
    for p in sorted(glob.glob(f"/tmp/pz-runs/{arm}/*.meta/grade.json")):
        g = json.load(open(p))
        out[g["scen"]].append(g)
    return out
def fails(g):
    f = []
    if g["regression"]: f.append("regress")
    if g["scen"] == "p3" and g["voice_phrases_kept"] != "4/4": f.append("voice")
    if g["scen"] == "p2" and g["changed"]: f.append("noop-changed")
    if g["scen"] in ("p1", "p2") and g["tests_edited_by_agent"]: f.append("tests-edited")
    if g["scen"] == "p2" and g["size_ratio"] > 1.0: f.append("grew")
    if g["perfect_claims"]: f.append("perfect-claim")
    return f
tiers = [("haiku", "A1h", "A2h", "A4h"), ("sonnet", "A1s", "A2s", "A4s"), ("opus", "A1", "A2", "A4")]
for tier, c, a2, a4 in tiers:
    print(f"\n=== {tier}")
    print(f"{'arm':6} {'scen':4} {'n':>2} {'valid':>5} {'fail-reps':>9}  failures | P1 size ratio / skill triggered / cost")
    for label, arm in (("ctrl", c), ("A2", a2), ("A4", a4)):
        d = load(arm)
        for s in ("p1", "p2", "p3"):
            runs = d.get(s, [])
            valid = [g for g in runs if not g.get("is_error")]
            fl = [fails(g) for g in valid]
            cnt = collections.Counter(k for x in fl for k in x)
            extra = ""
            if s == "p1" and valid: extra = f"size={[g['size_ratio'] for g in valid]}"
            trig = sum(1 for g in valid if g["skill_calls"]) if arm.startswith("A4") else None
            cost = round(sum(g.get("cost") or 0 for g in valid), 2)
            print(f"{label:6} {s:4} {len(runs):>2} {len(valid):>5} {sum(1 for x in fl if x):>6}/{len(valid)}  {dict(cnt) or '-'} | {extra} {'triggered=%d/%d' % (trig, len(valid)) if trig is not None else ''} ${cost}")
