#!/bin/bash
# usage: trigger_one.sh VARIANT ID MODEL
VAR=$1; ID=$2; MODEL=$3
LINE=$(awk -F'\t' -v id="$ID" '$1==id' /tmp/pz-harness/trigger_prompts.tsv)
FIXN=$(echo "$LINE" | cut -f2); EXP=$(echo "$LINE" | cut -f3); PROMPT=$(echo "$LINE" | cut -f4)
D=/tmp/pz-trig2/$MODEL/$VAR/$ID; rm -rf "$D"; mkdir -p "$D"; cp -R /tmp/pz-fixtures/$FIXN/. "$D/"
( cd "$D" && git init -q && git add -A && git -c user.email=t@t -c user.name=t commit -qm base )
for n in 1 2 3; do
  ( cd "$D" && timeout 900 claude -p "$PROMPT" --setting-sources project --no-session-persistence --output-format json \
     --permission-mode acceptEdits --max-turns 40 --model "$MODEL" \
     --allowedTools "Bash(bun:*)" "Bash(ls:*)" "Bash(cat:*)" "Bash(git:*)" "Bash(wc:*)" "Bash(diff:*)" "Bash(rg:*)" "Bash(grep:*)" "Bash(head:*)" "Bash(sed:*)" \
     --plugin-dir /tmp/pz-variants/$VAR/aio-perfectize < /dev/null > "$D/../$ID.json" 2> /dev/null )
  rg -q 'OAuth token revoked|Not logged in' "$D/../$ID.json" 2>/dev/null || break
  sleep 45
done
python3 -I - "$VAR" "$ID" "$MODEL" "$EXP" "$D/../$ID.json" <<'PY'
import json, sys
var, id_, model, exp, path = sys.argv[1:6]
try:
    ev = json.load(open(path))
    err = [e for e in ev if e.get("type") == "result"][-1].get("is_error")
    sk = [b.get("input", {}).get("skill") for e in ev if e.get("type") == "assistant" for b in e["message"]["content"]
          if isinstance(b, dict) and b.get("type") == "tool_use" and b["name"] == "Skill"]
    hit = any(s and "perfectize" in s for s in sk)
    print(json.dumps({"variant": var, "id": id_, "model": model, "expect": exp, "triggered": hit, "skills": sk, "error": bool(err)}))
except Exception as e:
    print(json.dumps({"variant": var, "id": id_, "model": model, "expect": exp, "error": True, "note": str(e)}))
PY
