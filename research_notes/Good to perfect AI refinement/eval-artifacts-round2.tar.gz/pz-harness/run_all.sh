#!/bin/bash
# usage: run_all.sh "ARM1 ARM2" "REPS" [MODEL]   (parallel across jobs)
ARMS=$1; REPS=$2; MODEL=${3:-}
for arm in $ARMS; do for scen in ${SCENS:-p1 p2 p3 p4}; do for rep in $REPS; do
  if [ -n "$MODEL" ]; then echo "$arm $scen $rep $MODEL"; else echo "$arm $scen $rep"; fi
done; done; done | xargs -P ${PAR:-2} -L 1 bash /tmp/pz-harness/run_one.sh
