import json, glob, collections, statistics
def load(arm):
    out = collections.defaultdict(list)
    for p in sorted(glob.glob(f"/tmp/pz-runs/{arm}/*.meta/grade.json")):
        g = json.load(open(p)); out[g["scen"]].append(g)
    return out
def restraint_fail(g):
    f = []
    s = g["scen"]
    if s in ("p1", "p2", "p4") and g["regression"]: f.append("regress")
    if s in ("p1", "p2") and g["tests_edited_by_agent"]: f.append("tests-edited")
    if s == "p2" and g["changed"]: f.append("noop-changed")
    if s == "p2" and g["size_ratio"] > 1.0: f.append("grew")
    if s == "p3" and g["voice_phrases_kept"] != "4/4": f.append("voice")
    if g["perfect_claims"]: f.append("perfect-claim")
    return f
tiers = [("sonnet", [("ctrl", "A1s"), ("sentence", "A2s"), ("skill V1", "A4s"), ("skill V2", "A5s")]),
         ("haiku", [("ctrl", "A1h"), ("sentence", "A2h"), ("skill V1", "A4h")])]
for tier, arms in tiers:
    print(f"\n=== {tier}  (n=5 per cell)")
    print(f"{'arm':9} | restraint failures p1/p2/p3 | p4 numbers fixed | p4 overclaim removed | p4 words x | p1 size x (median) | p1 dead code? | fired | cost")
    for label, arm in arms:
        d = load(arm)
        rf = {s: sum(1 for g in d[s] if restraint_fail(g)) for s in ("p1", "p2", "p3")}
        p4 = d["p4"]
        nf = sum(g["numbers_fixed"] for g in p4); oc = sum(g["overclaim_removed"] for g in p4)
        p4reg = sum(1 for g in p4 if g["regression"])
        wr = statistics.median(g["words_after"] / g["words_before"] for g in p4)
        sz = statistics.median(g["size_ratio"] for g in d["p1"])
        fired = sum(1 for s in d for g in d[s] if g["skill_calls"]) if arm.startswith(("A4", "A5")) else None
        tot = sum(1 for s in d for g in d[s])
        cost = sum(g["cost"] or 0 for s in d for g in d[s])
        print(f"{label:9} | {rf['p1']}/5 {rf['p2']}/5 {rf['p3']}/5 (any {sum(rf.values())}/15) | {nf}/5 (regress {p4reg}) | {oc}/5 | {wr:.2f} | {sz:.2f} | - | {f'{fired}/{tot}' if fired is not None else 'n/a':5} | ${cost:.2f}")
print("\nfailure types (p1-p3, all arms):")
for tier, arms in tiers:
    for label, arm in arms:
        d = load(arm); c = collections.Counter(k for s in ("p1","p2","p3") for g in d[s] for k in restraint_fail(g))
        print(f"  {tier:6} {label:9}", dict(c) or "-")
