import json, sys
sys.path.insert(0, "/tmp/pz-harness"); import judge
_o = judge.text
judge.text = lambda arm, scen, rep: open("/tmp/pz-calib/" + arm[4:]).read() if arm.startswith("CAL:") else _o(arm, scen, rep)
for a, b in (("CAL:fixed-p4.md", "CAL:padded-p4.md"),):
    r = judge.job(("len", "p4", "0", a, b))
    print(f"[{judge.JUDGE_MODEL}] plain(a) vs padded-with-filler(b): verdict={r['verdict']} orders={r.get('order1')}/{r.get('order2')} conf={r.get('conf')}")
