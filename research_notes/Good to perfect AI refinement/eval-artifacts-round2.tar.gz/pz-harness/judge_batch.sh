#!/bin/bash
cd /tmp
JUDGE_MODEL=opus   PAR=3 python3 -I /tmp/pz-harness/judge.py /tmp/pz-harness/judge_h2h.json /tmp/pz-runs/judge_h2h.jsonl
JUDGE_MODEL=sonnet PAR=3 python3 -I /tmp/pz-harness/judge.py /tmp/pz-harness/judge_vs.json  /tmp/pz-runs/judge_vs.jsonl
echo JUDGE-DONE
