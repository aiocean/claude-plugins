import json, sys, collections
rows = [json.loads(l) for l in open(sys.argv[1])]
print("errors:", sum(1 for r in rows if r["verdict"] == "error"), "of", len(rows), "| judge calls:", sum(r["calls"] for r in rows), "| cost: $%.2f" % sum(r["cost"] for r in rows))
agg = collections.defaultdict(lambda: collections.Counter())
for r in rows:
    if r["verdict"] == "error": continue
    key = (r["tier"], r["scen"], r["a"], r["b"])
    agg[key][{"a": "a_wins", "b": "b_wins", "tie": "tie"}[r["verdict"]]] += 1
print(f"{'tier':6} {'scen':4} {'candidate':9} vs {'other':9} | cand wins / ties / other wins")
for (tier, scen, a, b), c in sorted(agg.items()):
    print(f"{tier:6} {scen:4} {a:9} vs {b:9} | {c['a_wins']} / {c['tie']} / {c['b_wins']}   (n={sum(c.values())})")
