#!/bin/bash
cd /tmp
PAR=3 bash /tmp/pz-harness/run_all.sh "A1s A2s A4s A5s" "1 2 3 4 5" sonnet
PAR=3 bash /tmp/pz-harness/run_all.sh "A1h A2h A4h" "1 2 3 4 5" haiku
echo BATCH-DONE
