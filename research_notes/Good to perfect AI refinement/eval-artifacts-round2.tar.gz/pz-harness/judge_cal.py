import json, sys, os
sys.path.insert(0, "/tmp/pz-harness")
import judge
_orig = judge.text
def text(arm, scen, rep):
    if arm.startswith("CAL:"): return open("/tmp/pz-calib/" + arm[4:]).read()
    return _orig(arm, scen, rep)
judge.text = text
# (scenario, candidate, other, expected winner label)
cases = [("p3", "ORIG", "CAL:degraded-p3.md", "a"), ("p4", "CAL:fixed-p4.md", "ORIG", "a"), ("p4", "ORIG", "CAL:worse-p4.md", "a")]
out = []
for scen, a, b, exp in cases:
    r = judge.job(("cal", scen, "0", a, b)); r["expected"] = exp; r["model"] = judge.JUDGE_MODEL; out.append(r)
    print(f"[{judge.JUDGE_MODEL}] {scen}: {a} vs {b} -> verdict={r['verdict']} (expected {exp}) orders={r.get('order1')}/{r.get('order2')} conf={r.get('conf')} cost=${r.get('cost'):.3f}")
json.dump(out, open(f"/tmp/pz-runs/judge_cal_{judge.JUDGE_MODEL}.json", "w"))
