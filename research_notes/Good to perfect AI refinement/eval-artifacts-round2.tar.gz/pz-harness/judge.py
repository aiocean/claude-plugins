import json, os, re, subprocess, sys, tempfile, time, itertools
from concurrent.futures import ThreadPoolExecutor

RUNS, FIX = "/tmp/pz-runs", "/tmp/pz-fixtures"
FILE = {"p3": "post.md", "p4": "report.md"}
CTX = {
    "p3": "The document is a short personal blog post.",
    "p4": "The document is a short analysis memo. Its source data (data.csv) is: week,visits,signups / 1,10000,400 / 2,11000,550. Numbers in the memo must be correct against that data.",
}
JUDGE_MODEL = os.environ.get("JUDGE_MODEL", "opus")
EMPTY = tempfile.mkdtemp(prefix="pz-judge-cwd.")

def text(arm, scen, rep):
    if arm == "ORIG":
        return open(f"{FIX}/{scen}/{FILE[scen]}").read()
    return open(f"{RUNS}/{arm}/{scen}-{rep}/{FILE[scen]}").read()

def prompt(scen, orig, x, y):
    return f"""You are judging two revisions of the same document. The author asked an assistant to "make it perfect". {CTX[scen]}

Decide which revision is the better FINAL version for this author: it keeps their facts, meaning and distinctive voice, fixes real defects, and does not add material the author did not need. Length is not a virtue. If they are equally good, say tie.

Do not use tools. Reply with exactly one line of JSON: {{"winner":"X"|"Y"|"tie","confidence":"high"|"medium"|"low"}}

=== ORIGINAL (what the author started with) ===
{orig}

=== REVISION X ===
{x}

=== REVISION Y ===
{y}
"""

def call(p):
    for attempt in range(3):
        r = subprocess.run(["claude", "-p", p, "--model", JUDGE_MODEL, "--setting-sources", "project", "--no-session-persistence",
                            "--output-format", "json", "--max-turns", "2"], cwd=EMPTY, stdin=subprocess.DEVNULL,
                           capture_output=True, text=True, timeout=300)
        try:
            ev = json.loads(r.stdout)
            res = [e for e in ev if e.get("type") == "result"][-1]
            out = res.get("result") or ""
        except Exception as e:
            return {"error": f"parse: {e}", "raw": r.stdout[:200]}
        if any(k in out for k in ("OAuth token revoked", "Not logged in")):
            time.sleep(45); continue
        m = re.search(r'\{[^{}]*"winner"[^{}]*\}', out)
        if not m: return {"error": "no json", "raw": out[:200], "cost": res.get("total_cost_usd")}
        try: d = json.loads(m.group(0))
        except Exception: return {"error": "bad json", "raw": out[:200]}
        d["cost"] = res.get("total_cost_usd"); return d
    return {"error": "auth"}

def job(j):
    tier, scen, rep, a, b = j
    ta, tb = text(a, scen, rep), text(b, scen, rep)
    orig = text("ORIG", scen, rep)
    if ta == tb:
        return {"tier": tier, "scen": scen, "rep": rep, "a": a, "b": b, "verdict": "tie", "reason": "identical", "calls": 0, "cost": 0}
    r1 = call(prompt(scen, orig, ta, tb))   # a is X
    r2 = call(prompt(scen, orig, tb, ta))   # a is Y
    if "error" in r1 or "error" in r2:
        return {"tier": tier, "scen": scen, "rep": rep, "a": a, "b": b, "verdict": "error", "r1": r1, "r2": r2, "calls": 2, "cost": (r1.get("cost") or 0) + (r2.get("cost") or 0)}
    w1 = {"X": "a", "Y": "b", "tie": "tie"}[r1["winner"]]
    w2 = {"X": "b", "Y": "a", "tie": "tie"}[r2["winner"]]
    verdict = w1 if w1 == w2 else "tie"
    return {"tier": tier, "scen": scen, "rep": rep, "a": a, "b": b, "verdict": verdict, "order1": r1["winner"], "order2": r2["winner"],
            "conf": [r1.get("confidence"), r2.get("confidence")], "calls": 2, "cost": (r1.get("cost") or 0) + (r2.get("cost") or 0)}

if __name__ == "__main__":
    spec = json.load(open(sys.argv[1]))          # list of [tier, scen, rep, a_arm, b_arm]
    out = sys.argv[2]; done = set()
    if os.path.exists(out):
        for l in open(out): d = json.loads(l); done.add((d["tier"], d["scen"], d["rep"], d["a"], d["b"]))
    jobs = [tuple(j) for j in spec if tuple(j) not in done]
    with ThreadPoolExecutor(max_workers=int(os.environ.get("PAR", "3"))) as ex, open(out, "a") as f:
        for res in ex.map(job, jobs):
            f.write(json.dumps(res) + "\n"); f.flush()
    print("judged", len(jobs), "jobs")
