#!/bin/bash
# usage: run_one.sh ARM SCEN REP [MODEL]
ARM=$1; SCEN=$2; REP=$3; MODEL=${4:-}
[ -e /tmp/pz-runs/AUTH_FAIL ] && { echo "skip $ARM $SCEN $REP: AUTH_FAIL flag set"; exit 0; }
FIX=/tmp/pz-fixtures; RUN=/tmp/pz-runs/$ARM/$SCEN-$REP; META=/tmp/pz-runs/$ARM/$SCEN-$REP.meta
case $SCEN in p1) T=src/orders.ts;; p2) T=src/lru.ts;; p3) T=post.md;; p4) T=report.md;; esac
PROMPT="Make $T perfect."
EXTRA=()
case $ARM in
  A2*) PROMPT="$PROMPT Remove what is unnecessary first, change something only if you can show it is better, otherwise leave it unchanged.";;
  A4*) EXTRA=(--plugin-dir /Users/firegroup/projects/claude-plugins/plugins/aio-perfectize);;
  A5*) EXTRA=(--plugin-dir /tmp/pz-variants/V2/aio-perfectize);;
esac
[ -n "$MODEL" ] && EXTRA+=(--model "$MODEL")

attempt() {
  rm -rf "$RUN" "$META"; mkdir -p "$RUN" "$META"; cp -R "$FIX/$SCEN/." "$RUN/"
  ( cd "$RUN" && git init -q && git add -A && git -c user.email=t@t -c user.name=t commit -qm base && git rev-parse HEAD > "$META/base" )
  echo "$PROMPT" > "$META/prompt.txt"
  ( cd "$RUN" && timeout 1500 claude -p "$PROMPT" --setting-sources project --no-session-persistence --output-format json \
    --permission-mode acceptEdits --max-turns 40 \
    --allowedTools "Bash(bun:*)" "Bash(ls:*)" "Bash(cat:*)" "Bash(git:*)" "Bash(wc:*)" "Bash(diff:*)" "Bash(rg:*)" "Bash(grep:*)" "Bash(head:*)" "Bash(sed:*)" \
    "${EXTRA[@]}" < /dev/null > "$META/out.json" 2> "$META/err.txt" )
  echo "exit=$?" > "$META/exit.txt"
}
auth_error() { rg -q 'OAuth token revoked|Not logged in|"api_error_status":\s*401' "$META/out.json" 2>/dev/null; }

for n in 1 2 3; do
  attempt
  auth_error || break
  echo "auth error on $ARM $SCEN $REP attempt $n; retrying after 45s"; echo "$n" > "$META/auth_retries"
  sleep 45
done
if auth_error; then touch /tmp/pz-runs/AUTH_FAIL; echo "AUTH_FAIL persists for $ARM $SCEN $REP"; fi
python3 -I /tmp/pz-harness/grade.py "$ARM" "$SCEN" "$REP" > "$META/grade.json" 2> "$META/grade.err"
