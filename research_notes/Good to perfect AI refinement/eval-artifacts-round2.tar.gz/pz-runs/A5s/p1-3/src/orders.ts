export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;

export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((sum, line) => sum + lineTotal(line), 0);
}

function couponCents(coupon: string | undefined, subtotal: number): number {
  switch (coupon) {
    case "SAVE10":
      return Math.round(subtotal * 0.1);
    case "FLAT5":
      return 500;
    default:
      return 0;
  }
}

function discountCents(order: Order, subtotal: number): number {
  const bulk = subtotal >= 20000 ? Math.round(subtotal * 0.05) : 0;
  return Math.min(couponCents(order.coupon, subtotal) + bulk, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true, _legacy: boolean = false): number {
  const subtotal = orderSubtotal(order);
  const discount = discountCents(order, subtotal);
  const afterDiscount = subtotal - discount;
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const res: Record<string, number> = {};
  for (const o of orders) {
    res[o.customer] = (res[o.customer] ?? 0) + orderTotal(o);
  }
  return res;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  const names = Object.keys(totals).sort((a, b) => {
    if (totals[b] !== totals[a]) return totals[b] - totals[a];
    return a < b ? -1 : a > b ? 1 : 0;
  });
  const out: string[] = [];
  for (let i = 0; i < names.length && i < n; i++) {
    out.push(names[i]);
  }
  return out;
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return sign + "$" + dollarsStr + "." + (rem < 10 ? "0" + rem : "" + rem);
}
