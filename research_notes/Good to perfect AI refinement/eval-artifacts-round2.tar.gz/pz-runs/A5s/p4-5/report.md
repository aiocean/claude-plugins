# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1. Visits also grew, from 10,000 to 11,000, so some of the lift is simply more traffic. The rest is a better conversion rate: at week 1's rate, 11,000 visits would have produced 440 signups, so about 40 of the 150 extra signups come from traffic and about 110 from conversion.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement. The shorter signup form we shipped on Monday of week 2 is the likely cause, but this is a single before/after comparison, so it does not prove it. We should roll the same pattern out to the pricing page next and compare against a control.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
