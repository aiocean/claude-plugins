export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;

export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((sum, line) => sum + lineTotal(line), 0);
}

function discountCents(order: Order, subtotal: number): number {
  let d = 0;
  if (order.coupon === "SAVE10") {
    d = Math.round(subtotal * 0.1);
  } else if (order.coupon === "FLAT5") {
    d = 500;
  }
  if (subtotal >= 20000) {
    d += Math.round(subtotal * 0.05);
  }
  return Math.min(d, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true, _legacy: boolean = false): number {
  const subtotal = orderSubtotal(order);
  const discount = discountCents(order, subtotal);
  const afterDiscount = subtotal - discount;
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const res: Record<string, number> = {};
  for (const o of orders) {
    res[o.customer] = (res[o.customer] ?? 0) + orderTotal(o);
  }
  return res;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  const names = Object.keys(totals);
  const tmp = names.map((name) => ({ name: name, total: totals[name] }));
  tmp.sort((a, b) => {
    if (b.total !== a.total) return b.total - a.total;
    if (a.name < b.name) return -1;
    if (a.name > b.name) return 1;
    return 0;
  });
  const out: string[] = [];
  for (let i = 0; i < tmp.length && i < n; i++) {
    out.push(tmp[i].name);
  }
  return out;
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return sign + "$" + dollarsStr + "." + (rem < 10 ? "0" + rem : "" + rem);
}
