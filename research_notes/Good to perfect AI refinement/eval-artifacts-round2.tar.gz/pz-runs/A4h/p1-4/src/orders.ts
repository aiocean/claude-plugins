export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const SAVE10_RATE = 0.1;
const FLAT5_CENTS = 500;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_RATE = 0.05;

// Total for one line
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  let total = 0;
  for (const line of order.lines) {
    total += lineTotal(line);
  }
  return total;
}

function couponCents(coupon: string | undefined, subtotal: number): number {
  if (coupon === "SAVE10") return Math.round(subtotal * SAVE10_RATE);
  if (coupon === "FLAT5") return FLAT5_CENTS;
  return 0;
}

function discountCents(order: Order, subtotal: number): number {
  let d = couponCents(order.coupon, subtotal);
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    d += Math.round(subtotal * BULK_RATE);
  }
  return Math.min(d, subtotal);
}

export function orderTotal(order: Order, includeTax = true, _legacy = false): number {
  const subtotal = orderSubtotal(order);
  const discount = discountCents(order, subtotal);
  const afterDiscount = subtotal - discount;
  if (!includeTax) return afterDiscount;
  return afterDiscount + Math.round(afterDiscount * TAX_RATE);
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const res: Record<string, number> = Object.create(null);
  for (const o of orders) {
    res[o.customer] = (res[o.customer] ?? 0) + orderTotal(o);
  }
  return res;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  const names = Object.keys(totals);
  const tmp = names.map((name) => ({ name: name, total: totals[name] }));
  tmp.sort((a, b) => {
    if (b.total !== a.total) return b.total - a.total;
    if (a.name < b.name) return -1;
    if (a.name > b.name) return 1;
    return 0;
  });
  const out: string[] = [];
  for (let i = 0; i < tmp.length && i < n; i++) {
    out.push(tmp[i].name);
  }
  return out;
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return sign + "$" + dollarsStr + "." + String(rem).padStart(2, "0");
}
