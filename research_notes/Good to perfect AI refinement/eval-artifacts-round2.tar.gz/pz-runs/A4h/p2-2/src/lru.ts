/**
 * Map-like cache holding at most `capacity` entries. When full, `set` evicts
 * the least recently used entry. `get` and `set` mark a key as most recently
 * used; `has` and `delete` do not change recency.
 */
export class LRUCache<K, V> {
  private readonly map = new Map<K, V>();

  /** @throws {RangeError} if `capacity` is not a positive integer. */
  constructor(private readonly capacity: number) {
    if (!Number.isInteger(capacity) || capacity < 1) {
      throw new RangeError("capacity must be a positive integer");
    }
  }

  get size(): number {
    return this.map.size;
  }

  /** Returns the value for `key`, or `undefined` if absent. Refreshes recency on hit. */
  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key) as V;
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.capacity) {
      this.map.delete(this.map.keys().next().value as K);
    }
  }

  has(key: K): boolean {
    return this.map.has(key);
  }

  delete(key: K): boolean {
    return this.map.delete(key);
  }
}
