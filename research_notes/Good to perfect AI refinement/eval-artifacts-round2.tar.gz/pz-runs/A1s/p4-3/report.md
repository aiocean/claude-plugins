# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1 (+37.5%). Visits also grew, from 10,000 to 11,000 (+10%), so some of the lift is simply more traffic. The rest is a better conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement (+1.0 percentage point).

Of the 150 additional signups, about 40 are explained by traffic (11,000 visits at the week 1 rate of 4.0% would give 440 signups). The remaining 110 come from the higher conversion rate.

The shorter signup form shipped on Monday of week 2, so it is a plausible driver of the conversion gain. This data cannot confirm it, though: there was no control group, only two weeks of data, and other changes (traffic mix, seasonality, campaigns) could also explain the difference. Before rolling the same pattern out to the pricing page, we should confirm the effect, ideally with an A/B test of the form, or at least by checking whether conversion stays near 5.0% over several more weeks.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
