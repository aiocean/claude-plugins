export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;

/** Total for one line, in cents. */
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function discountCents(order: Order, subtotal: number): number {
  let discount = 0;
  if (order.coupon === "SAVE10") {
    discount = Math.round(subtotal * 0.1);
  } else if (order.coupon === "FLAT5") {
    discount = 500;
  }
  if (subtotal >= 20000) {
    discount += Math.round(subtotal * 0.05);
  }
  return Math.min(discount, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  // Null prototype so customer names like "constructor" or "__proto__" are plain keys.
  const totals: Record<string, number> = Object.create(null);
  for (const order of orders) {
    totals[order.customer] = (totals[order.customer] ?? 0) + orderTotal(order);
  }
  return totals;
}

export function topCustomers(orders: Order[], n: number): string[] {
  return Object.entries(totalsByCustomer(orders))
    .sort(([nameA, totalA], [nameB, totalB]) => {
      if (totalA !== totalB) return totalB - totalA;
      return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
    })
    .slice(0, Math.max(0, n))
    .map(([name]) => name);
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${sign}$${dollarsStr}.${String(rem).padStart(2, "0")}`;
}
