# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1 (+37.5%). Visits also grew, from 10,000 to 11,000 (+10%), so some of the lift is simply more traffic. The rest is a better conversion rate: at week 1's 4.0% rate, 11,000 visits would have produced 440 signups, so about 40 of the 150 extra signups come from traffic and about 110 from higher conversion.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement (+1.0 percentage point).

We shipped a shorter signup form on Monday of week 2, which is the most likely driver of the gain. However, two weeks of data with no control group cannot confirm it: seasonality, traffic mix, or other changes could also explain the shift. Before rolling the same pattern out to the pricing page, we should confirm the effect, ideally with an A/B test or at least another week of data at the new baseline.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
