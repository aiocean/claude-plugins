# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1 (+37.5%). Visits also grew, from 10,000 to 11,000 (+10%), so some of the lift is simply more traffic. The rest is a better conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 1.0 percentage point (25% relative) improvement. Of the 150 additional signups, about 40 are explained by the extra traffic (11,000 × 4.0% = 440) and about 110 by the higher conversion rate.

We shipped a shorter signup form on Monday of week 2, which is the most likely driver of the gain. However, this is a single before/after comparison over two weeks with no control group, so we can't yet rule out other causes (seasonality, traffic mix, other changes). Before rolling the same pattern out to the pricing page, we should confirm the effect, ideally with an A/B test or at least another week of data.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
