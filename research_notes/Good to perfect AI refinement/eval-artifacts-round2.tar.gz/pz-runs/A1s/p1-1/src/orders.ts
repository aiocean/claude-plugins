export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const SAVE10_RATE = 0.1;
const FLAT5_CENTS = 500;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_RATE = 0.05;

/** Total for one line, in cents. */
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function discountCents(order: Order, subtotal: number): number {
  let discount = 0;
  if (order.coupon === "SAVE10") {
    discount = Math.round(subtotal * SAVE10_RATE);
  } else if (order.coupon === "FLAT5") {
    discount = FLAT5_CENTS;
  }
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    discount += Math.round(subtotal * BULK_RATE);
  }
  return Math.min(discount, subtotal);
}

// `_legacy` is unused; kept so existing three-argument callers still compile.
export function orderTotal(order: Order, includeTax: boolean = true, _legacy: boolean = false): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const res: Record<string, number> = {};
  for (const o of orders) {
    res[o.customer] = (res[o.customer] ?? 0) + orderTotal(o);
  }
  return res;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  const names = Object.keys(totals);
  names.sort((a, b) => {
    if (totals[b] !== totals[a]) return totals[b] - totals[a];
    return a < b ? -1 : a > b ? 1 : 0;
  });
  return names.slice(0, Math.max(0, n));
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${sign}$${dollarsStr}.${String(rem).padStart(2, "0")}`;
}
