# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1 (+37.5%). Visits also grew, from 10,000 to 11,000 (+10%), so some of the lift is simply more traffic. The rest is a better conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement (+1.0 percentage point). Of the 150 additional signups, about 40 are explained by extra traffic (11,000 visits at the week 1 rate of 4.0% would give 440), and about 110 by the higher conversion rate.

We shipped a shorter signup form on Monday of week 2, which is a plausible driver of the gain. However, this data covers only two weeks and has no control group, so it cannot show that the form caused the improvement; other changes in traffic mix or seasonality could also contribute. Before rolling the same pattern out to the pricing page, we should confirm the effect, ideally with an A/B test or at least another week of data.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
