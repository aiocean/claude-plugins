# We cut our deploy from 40 minutes to 6

Last March our deploy took 40 minutes. Nobody trusted it, so nobody shipped on Fridays, and many Tuesdays became a queue of people waiting on the one person who understood the pipeline. That person was Priya, and she was tired of being the pipeline.

We did not rewrite anything. We spent two weeks reading the build logs line by line, and the picture was dull. Of the 40 minutes, 31 went to downloading the same dependencies we had downloaded the day before. We were paying our CI provider $1,900 a month to fetch the same small packages over and over.

So we added three caches: one for the package manager, one for the compiled assets, one for the Docker layers. That was the whole project. The first cached run took 14 minutes, which felt like a miracle until we noticed a timestamp in a build file was invalidating the Docker cache. Priya fixed that in one afternoon with a very small diff.

After that the deploy took 6 minutes. The monthly bill dropped to $620. The Friday rule is gone. We don't deploy carelessly on Fridays; we just deploy.

What I took from it is that the slow part is rarely the part you suspect. We had a long list of clever ideas, parallel test shards, a faster runner, a new orchestrator. Each would have been a bigger project than the three caches, and none would have touched those 31 minutes. Read the logs first. It is boring and it works.
