# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1 (+150, or +37.5%). Visits also grew, from 10,000 to 11,000 (+10%), so part of the lift is simply more traffic. The rest is a better conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Of the 150 additional signups, about 40 are explained by traffic (1,000 extra visits at week 1's 4.0% rate = 40). The remaining 110 come from the higher conversion rate.

Conversion rose from 4.0% to 5.0%, a 1.0 percentage point (25% relative) improvement.

We shipped a shorter signup form on Monday of week 2, and it is the most likely driver of the conversion gain. This data cannot confirm that. It is a single before/after comparison with no control group, and other changes (seasonality, channel mix, campaigns) could also explain the lift. Two weeks of data also give no sense of normal week-to-week variation. Before rolling the same pattern out to the pricing page, we should run it as an A/B test or at least confirm the gain holds in week 3.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
