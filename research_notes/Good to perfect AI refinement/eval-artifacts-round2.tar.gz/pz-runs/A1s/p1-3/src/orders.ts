export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_DISCOUNT_RATE = 0.05;
const SAVE10_RATE = 0.1;
const FLAT5_CENTS = 500;

/** Total in cents for one line. */
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

/** Sum of all line totals in cents, before discounts and tax. */
export function orderSubtotal(order: Order): number {
  return order.lines.reduce((sum, line) => sum + lineTotal(line), 0);
}

function couponDiscountCents(coupon: string | undefined, subtotal: number): number {
  switch (coupon) {
    case "SAVE10":
      return Math.round(subtotal * SAVE10_RATE);
    case "FLAT5":
      return FLAT5_CENTS;
    default:
      return 0;
  }
}

/** Coupon plus bulk discount, capped so it never exceeds the subtotal. */
function discountCents(order: Order, subtotal: number): number {
  let discount = couponDiscountCents(order.coupon, subtotal);
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    discount += Math.round(subtotal * BULK_DISCOUNT_RATE);
  }
  return Math.min(discount, subtotal);
}

/** Order total in cents after discounts, optionally including tax. */
export function orderTotal(order: Order, includeTax: boolean = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

/** Tax-inclusive totals in cents, keyed by customer. */
export function totalsByCustomer(orders: Order[]): Record<string, number> {
  // Map avoids prototype pitfalls with customer names like "__proto__".
  const totals = new Map<string, number>();
  for (const order of orders) {
    totals.set(order.customer, (totals.get(order.customer) ?? 0) + orderTotal(order));
  }
  return Object.fromEntries(totals);
}

/** Names of the top `n` customers by total, ties broken alphabetically. */
export function topCustomers(orders: Order[], n: number): string[] {
  return Object.entries(totalsByCustomer(orders))
    .sort(([nameA, totalA], [nameB, totalB]) => {
      if (totalB !== totalA) return totalB - totalA;
      return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
    })
    .slice(0, Math.max(0, n))
    .map(([name]) => name);
}

/** Formats cents as a dollar string, e.g. 123456 -> "$1,234.56". */
export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${sign}$${dollarsStr}.${rem.toString().padStart(2, "0")}`;
}
