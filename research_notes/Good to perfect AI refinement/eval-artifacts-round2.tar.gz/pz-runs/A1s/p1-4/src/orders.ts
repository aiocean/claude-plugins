export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const SAVE10_RATE = 0.1;
const FLAT5_CENTS = 500;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_RATE = 0.05;

export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function couponDiscountCents(coupon: string | undefined, subtotal: number): number {
  switch (coupon) {
    case "SAVE10":
      return Math.round(subtotal * SAVE10_RATE);
    case "FLAT5":
      return FLAT5_CENTS;
    default:
      return 0;
  }
}

function discountCents(order: Order, subtotal: number): number {
  let discount = couponDiscountCents(order.coupon, subtotal);
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    discount += Math.round(subtotal * BULK_RATE);
  }
  return Math.min(discount, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const order of orders) {
    const previous = Object.hasOwn(totals, order.customer) ? totals[order.customer] : 0;
    totals[order.customer] = previous + orderTotal(order);
  }
  return totals;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  return Object.keys(totals)
    .sort((a, b) => totals[b] - totals[a] || (a < b ? -1 : a > b ? 1 : 0))
    .slice(0, Math.max(0, n));
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${sign}$${dollars}.${(abs % 100).toString().padStart(2, "0")}`;
}
