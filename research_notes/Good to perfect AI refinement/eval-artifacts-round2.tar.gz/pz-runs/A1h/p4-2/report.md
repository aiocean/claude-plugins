# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1. Visits also grew, from 10,000 to 11,000. Of the 150 extra signups, about 40 come from the added traffic and about 110 from a higher conversion rate.

Conversion is signups divided by visits.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement. The shorter signup form shipped on Monday of week 2 coincided with this gain. This data does not isolate its effect, since there is no control group and no daily breakdown. Before rolling the same pattern out to the pricing page, we should confirm the effect, for example with an A/B test.

The traffic and conversion split uses week 1's 4.0% rate: 1,000 extra visits at 4.0% gives 40 signups, and the remaining 110 come from the rate change on 11,000 visits.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
