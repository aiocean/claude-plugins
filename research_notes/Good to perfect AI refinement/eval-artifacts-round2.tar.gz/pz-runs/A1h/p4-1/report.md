# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1. Visits also grew, from 10,000 to 11,000, so part of the lift is simply more traffic. The rest comes from a higher conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a one-point gain, or a 25% relative improvement. At week 1's conversion rate, week 2's extra traffic accounts for about 40 of the 150 additional signups; the higher conversion rate accounts for the other 110.

The shorter signup form we shipped on Monday of week 2 coincides with this gain. The comparison is before and after, with no control group, so it cannot confirm that the form caused the increase; other changes or seasonality could contribute. We should test the shorter form against the old one, and if the result holds, roll the same pattern out to the pricing page.

Raw numbers are in data.csv. Next week we will keep tracking weekly visits, signups, and conversion.
