export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const SAVE10_RATE = 0.1;
const FLAT5_CENTS = 500;
const VOLUME_THRESHOLD_CENTS = 20000;
const VOLUME_RATE = 0.05;

// Total for one line
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((sum, line) => sum + lineTotal(line), 0);
}

function couponCents(coupon: string | undefined, subtotal: number): number {
  switch (coupon) {
    case "SAVE10":
      return Math.round(subtotal * SAVE10_RATE);
    case "FLAT5":
      return FLAT5_CENTS;
    default:
      return 0;
  }
}

function discountCents(order: Order, subtotal: number): number {
  let d = couponCents(order.coupon, subtotal);
  if (subtotal >= VOLUME_THRESHOLD_CENTS) {
    d += Math.round(subtotal * VOLUME_RATE);
  }
  return Math.min(d, subtotal);
}

export function orderTotal(order: Order, includeTax = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  if (!includeTax) {
    return afterDiscount;
  }
  return afterDiscount + Math.round(afterDiscount * TAX_RATE);
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  // Map instead of a plain object so names like "constructor" or "__proto__" are safe keys
  const totals = new Map<string, number>();
  for (const order of orders) {
    totals.set(order.customer, (totals.get(order.customer) ?? 0) + orderTotal(order));
  }
  return Object.fromEntries(totals);
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  return Object.keys(totals)
    .sort((a, b) => {
      if (totals[b] !== totals[a]) return totals[b] - totals[a];
      if (a < b) return -1;
      if (a > b) return 1;
      return 0;
    })
    .slice(0, Math.max(0, n));
}

export function formatCents(cents: number): string {
  const whole = Math.round(Math.abs(cents));
  const sign = cents < 0 && whole !== 0 ? "-" : "";
  const dollars = Math.floor(whole / 100);
  const rem = whole % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return sign + "$" + dollarsStr + "." + rem.toString().padStart(2, "0");
}
