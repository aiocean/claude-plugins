export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_RATE = 0.05;

const COUPON_DISCOUNTS = new Map<string, (subtotal: number) => number>([
  ["SAVE10", (subtotal) => Math.round(subtotal * 0.1)],
  ["FLAT5", () => 500],
]);

// Total for one line
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function discountCents(order: Order, subtotal: number): number {
  const couponDiscount = order.coupon ? COUPON_DISCOUNTS.get(order.coupon) : undefined;
  let discount = couponDiscount ? couponDiscount(subtotal) : 0;
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    discount += Math.round(subtotal * BULK_RATE);
  }
  return Math.min(discount, subtotal);
}

export function orderTotal(order: Order, includeTax = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

// Map rather than a plain object so customer names like "constructor" or "__proto__" are safe keys
function customerTotals(orders: Order[]): Map<string, number> {
  const totals = new Map<string, number>();
  for (const o of orders) {
    totals.set(o.customer, (totals.get(o.customer) ?? 0) + orderTotal(o));
  }
  return totals;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  return Object.fromEntries(customerTotals(orders));
}

export function topCustomers(orders: Order[], n: number): string[] {
  const ranked = [...customerTotals(orders)].sort(([nameA, totalA], [nameB, totalB]) => {
    if (totalB !== totalA) return totalB - totalA;
    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
  });
  return ranked.slice(0, Math.max(0, n)).map(([name]) => name);
}

export function formatCents(cents: number): string {
  const whole = Math.round(cents);
  const sign = whole < 0 ? "-" : "";
  const abs = Math.abs(whole);
  const dollars = Math.floor(abs / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const rem = (abs % 100).toString().padStart(2, "0");
  return `${sign}$${dollars}.${rem}`;
}
