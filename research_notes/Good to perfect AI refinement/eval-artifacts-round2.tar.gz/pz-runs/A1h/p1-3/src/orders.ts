export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const SAVE10_RATE = 0.1;
const FLAT5_CENTS = 500;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_RATE = 0.05;

// Total for one line
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function couponDiscount(coupon: string | undefined, subtotal: number): number {
  switch (coupon) {
    case "SAVE10":
      return Math.round(subtotal * SAVE10_RATE);
    case "FLAT5":
      return FLAT5_CENTS;
    default:
      return 0;
  }
}

function discountCents(order: Order, subtotal: number): number {
  let discount = couponDiscount(order.coupon, subtotal);
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    discount += Math.round(subtotal * BULK_RATE);
  }
  return Math.min(discount, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  if (!includeTax) {
    return afterDiscount;
  }
  return afterDiscount + Math.round(afterDiscount * TAX_RATE);
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  // Map instead of a plain object so customer names like "constructor" or "__proto__" are safe keys
  const totals = new Map<string, number>();
  for (const order of orders) {
    totals.set(order.customer, (totals.get(order.customer) ?? 0) + orderTotal(order));
  }
  return Object.fromEntries(totals);
}

export function topCustomers(orders: Order[], n: number): string[] {
  const ranked = Object.entries(totalsByCustomer(orders)).sort(([aName, aTotal], [bName, bTotal]) => {
    if (bTotal !== aTotal) return bTotal - aTotal;
    if (aName < bName) return -1;
    if (aName > bName) return 1;
    return 0;
  });
  return ranked.slice(0, Math.max(0, n)).map(([name]) => name);
}

export function formatCents(cents: number): string {
  const whole = Math.round(cents);
  const sign = whole < 0 ? "-" : "";
  const abs = Math.abs(whole);
  const dollars = Math.floor(abs / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const rem = (abs % 100).toString().padStart(2, "0");
  return `${sign}$${dollars}.${rem}`;
}
