# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1, a 37.5% increase. Visits also grew, from 10,000 to 11,000 (+10%), so part of the lift is simply more traffic. Holding conversion at the week 1 rate, 11,000 visits would have produced about 440 signups, so roughly 40 of the 150 extra signups came from traffic and roughly 110 from a higher conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement (one percentage point). The shorter signup form shipped on Monday of week 2 coincided with this gain, but a week-over-week comparison does not isolate its effect: other changes in traffic mix or seasonality could also contribute. Before rolling the same pattern out to the pricing page, we should test it with a controlled experiment (for example, an A/B split on the pricing page) and confirm the lift.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
