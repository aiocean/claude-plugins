# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1, a 37.5% increase. Visits also grew, from 10,000 to 11,000 (+10%), so part of the lift is simply more traffic. The rest is a higher conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement (one percentage point).

Splitting the 150-signup increase:

- **More traffic:** 1,000 extra visits at the week 1 rate of 4.0% = 40 signups.
- **Higher conversion:** 11,000 visits at the 1-point increase = 110 signups.

So about 27% of the increase comes from traffic and about 73% from conversion.

The shorter signup form shipped on Monday of week 2 coincides with the conversion gain, but two weeks of data cannot isolate its effect from other changes. Before rolling the same pattern out to the pricing page, we should test it there, for example with an A/B split, and measure conversion directly.

Raw numbers are in data.csv. Next week we will keep tracking both weekly visits and signups.
