# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1, a 37.5% increase. Visits also grew, from 10,000 to 11,000 (+10%). At the week 1 conversion rate, 11,000 visits would have produced about 440 signups. So roughly 40 of the 150 extra signups came from more traffic, and roughly 110 came from a higher conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 1.0 percentage point gain or a 25% relative improvement.

The shorter signup form shipped on Monday of week 2, and the conversion gain coincides with it. Two weeks of data with no control group cannot show that the form caused the gain, so treat it as a hypothesis. Before rolling the same change out to the pricing page, run an A/B test there or confirm the lift holds over more weeks.

Raw numbers are in data.csv. Next week we will keep tracking weekly visits, signups, and conversion.
