/**
 * Fixed-capacity least-recently-used cache.
 *
 * Relies on `Map` preserving insertion order: the first key is the least
 * recently used, and every read or write moves the key to the end.
 */
export class LRUCache<K, V> {
  private readonly map = new Map<K, V>();

  constructor(private readonly capacity: number) {
    if (!Number.isInteger(capacity) || capacity < 1) {
      throw new RangeError("capacity must be a positive integer");
    }
  }

  get size(): number {
    return this.map.size;
  }

  /** Returns the value for `key` and marks it as most recently used. */
  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key) as V;
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  /** Returns the value for `key` without changing its recency. */
  peek(key: K): V | undefined {
    return this.map.get(key);
  }

  /** Inserts or updates `key` as most recently used, evicting the LRU entry if over capacity. */
  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.capacity) {
      this.map.delete(this.map.keys().next().value as K);
    }
  }

  /** Checks membership without changing recency. */
  has(key: K): boolean {
    return this.map.has(key);
  }

  delete(key: K): boolean {
    return this.map.delete(key);
  }

  clear(): void {
    this.map.clear();
  }
}
