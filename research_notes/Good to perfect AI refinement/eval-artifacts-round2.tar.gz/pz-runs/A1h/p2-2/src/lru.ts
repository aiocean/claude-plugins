/**
 * A fixed-capacity least-recently-used cache.
 *
 * Recency is tracked by the insertion order of a `Map`: the first key is always
 * the least recently used, and every `get` or `set` moves its key to the end.
 */
export class LRUCache<K, V> {
  private readonly map = new Map<K, V>();

  constructor(private readonly capacity: number) {
    if (!Number.isInteger(capacity) || capacity < 1) {
      throw new RangeError("capacity must be a positive integer");
    }
  }

  /** Number of entries currently stored. */
  get size(): number {
    return this.map.size;
  }

  /** Returns the value for `key` and marks it as most recently used. */
  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key) as V;
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  /** Inserts or updates `key` as most recently used, evicting the oldest entry if over capacity. */
  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.capacity) {
      this.map.delete(this.map.keys().next().value as K);
    }
  }

  /** Checks for `key` without changing its recency. */
  has(key: K): boolean {
    return this.map.has(key);
  }

  /** Removes `key`. Returns `true` if it was present. */
  delete(key: K): boolean {
    return this.map.delete(key);
  }

  /** Removes all entries. */
  clear(): void {
    this.map.clear();
  }
}
