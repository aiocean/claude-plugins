/**
 * A fixed-capacity key/value cache that evicts the least recently used entry
 * when a new key would exceed its capacity.
 *
 * Recency is refreshed by `set` and by a successful `get`. `has`, `delete`
 * and `size` leave recency unchanged.
 */
export class LRUCache<K, V> {
  // Map preserves insertion order, so the first key is always the LRU entry.
  private readonly map = new Map<K, V>();

  constructor(private readonly capacity: number) {
    if (!Number.isInteger(capacity) || capacity < 1) {
      throw new RangeError("capacity must be a positive integer");
    }
  }

  get size(): number {
    return this.map.size;
  }

  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key) as V;
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.capacity) {
      this.map.delete(this.map.keys().next().value as K);
    }
  }

  has(key: K): boolean {
    return this.map.has(key);
  }

  delete(key: K): boolean {
    return this.map.delete(key);
  }
}
