/**
 * A fixed-capacity least-recently-used cache.
 *
 * Backed by a `Map`, whose iteration order is insertion order. Every read or
 * write moves the entry to the end, so the first key is always the least
 * recently used and is the one evicted when the cache overflows.
 */
export class LRUCache<K, V> {
  private readonly map = new Map<K, V>();

  /**
   * @throws {RangeError} if `capacity` is not a positive integer.
   */
  constructor(private readonly capacity: number) {
    if (!Number.isInteger(capacity) || capacity < 1) {
      throw new RangeError("capacity must be a positive integer");
    }
  }

  /** Number of entries currently stored. */
  get size(): number {
    return this.map.size;
  }

  /**
   * Returns the value for `key` and marks it as most recently used.
   * Returns `undefined` if the key is absent.
   */
  get(key: K): V | undefined {
    if (!this.map.has(key)) return undefined;
    const value = this.map.get(key) as V;
    this.map.delete(key);
    this.map.set(key, value);
    return value;
  }

  /**
   * Inserts or updates `key` and marks it as most recently used. If this
   * pushes the cache over capacity, the least recently used entry is evicted.
   */
  set(key: K, value: V): void {
    this.map.delete(key);
    this.map.set(key, value);
    if (this.map.size > this.capacity) {
      this.map.delete(this.map.keys().next().value as K);
    }
  }

  /**
   * Returns whether `key` is present. Does not affect recency.
   */
  has(key: K): boolean {
    return this.map.has(key);
  }

  /**
   * Removes `key`. Returns `true` if it was present.
   */
  delete(key: K): boolean {
    return this.map.delete(key);
  }
}
