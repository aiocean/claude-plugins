export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;
const BULK_THRESHOLD_CENTS = 20000;
const BULK_DISCOUNT_RATE = 0.05;

// Total for one line
export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function couponCents(coupon: string | undefined, subtotal: number): number {
  switch (coupon) {
    case "SAVE10":
      return Math.round(subtotal * 0.1);
    case "FLAT5":
      return 500;
    default:
      return 0;
  }
}

function discountCents(order: Order, subtotal: number): number {
  let discount = couponCents(order.coupon, subtotal);
  if (subtotal >= BULK_THRESHOLD_CENTS) {
    discount += Math.round(subtotal * BULK_DISCOUNT_RATE);
  }
  return Math.min(discount, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  if (!includeTax) {
    return afterDiscount;
  }
  return afterDiscount + Math.round(afterDiscount * TAX_RATE);
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  // Map instead of a plain object so customer names like "constructor" or "__proto__" are safe keys
  const totals = new Map<string, number>();
  for (const order of orders) {
    totals.set(order.customer, (totals.get(order.customer) ?? 0) + orderTotal(order, true));
  }
  return Object.fromEntries(totals);
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = Object.entries(totalsByCustomer(orders));
  totals.sort(([nameA, totalA], [nameB, totalB]) => {
    if (totalB !== totalA) return totalB - totalA;
    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
  });
  return totals.slice(0, Math.max(n, 0)).map(([name]) => name);
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return sign + "$" + dollarsStr + "." + (rem < 10 ? "0" + rem : "" + rem);
}
