# Signup funnel: week 2 results

Week 2 signups rose to 550, up from 400 in week 1. Visits also grew, from 10,000 to 11,000, so some of the lift is simply more traffic. The rest is a better conversion rate.

| Week | Visits | Signups | Conversion |
|------|--------|---------|------------|
| 1    | 10,000 | 400     | 4.0%       |
| 2    | 11,000 | 550     | 5.0%       |

Conversion rose from 4.0% to 5.0%, a 25% relative improvement. The shorter signup form shipped on Monday of week 2, but with no control group and only two weeks of data, we can't attribute the gain to it. Testing the same pattern on the pricing page, with a control, would show whether it holds.

Raw numbers are in data.csv.
