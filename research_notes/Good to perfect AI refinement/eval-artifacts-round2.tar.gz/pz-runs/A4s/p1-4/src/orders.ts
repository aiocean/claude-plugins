export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;

export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function couponCents(coupon: string | undefined, subtotal: number): number {
  if (coupon === "SAVE10") return Math.round(subtotal * 0.1);
  if (coupon === "FLAT5") return 500;
  return 0;
}

function discountCents(order: Order, subtotal: number): number {
  let discount = couponCents(order.coupon, subtotal);
  if (subtotal >= 20000) {
    discount += Math.round(subtotal * 0.05);
  }
  return Math.min(discount, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true, _legacy: boolean = false): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const order of orders) {
    totals[order.customer] = (totals[order.customer] ?? 0) + orderTotal(order);
  }
  return totals;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  return Object.keys(totals)
    .sort((a, b) => totals[b] - totals[a] || (a < b ? -1 : a > b ? 1 : 0))
    .filter((_, i) => i < n);
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const rem = abs % 100;
  return `${sign}$${dollars}.${rem < 10 ? "0" : ""}${rem}`;
}
