export interface OrderLine {
  sku: string;
  qty: number;
  unitCents: number;
}

export interface Order {
  id: string;
  customer: string;
  lines: OrderLine[];
  coupon?: string;
}

const TAX_RATE = 0.08;

export function lineTotal(line: OrderLine): number {
  return line.qty * line.unitCents;
}

export function orderSubtotal(order: Order): number {
  return order.lines.reduce((total, line) => total + lineTotal(line), 0);
}

function discountCents(order: Order, subtotal: number): number {
  let d = 0;
  if (order.coupon === "SAVE10") {
    d = Math.round(subtotal * 0.1);
  } else if (order.coupon === "FLAT5") {
    d = 500;
  }
  if (subtotal >= 20000) {
    d += Math.round(subtotal * 0.05);
  }
  return Math.min(d, subtotal);
}

export function orderTotal(order: Order, includeTax: boolean = true, _legacy: boolean = false): number {
  const subtotal = orderSubtotal(order);
  const afterDiscount = subtotal - discountCents(order, subtotal);
  return includeTax ? afterDiscount + Math.round(afterDiscount * TAX_RATE) : afterDiscount;
}

export function totalsByCustomer(orders: Order[]): Record<string, number> {
  const res: Record<string, number> = {};
  for (const o of orders) {
    res[o.customer] = (res[o.customer] ?? 0) + orderTotal(o, true);
  }
  return res;
}

export function topCustomers(orders: Order[], n: number): string[] {
  const totals = totalsByCustomer(orders);
  return Object.keys(totals)
    .sort((a, b) => totals[b] - totals[a] || (a < b ? -1 : a > b ? 1 : 0))
    .slice(0, Math.max(n, 0));
}

export function formatCents(cents: number): string {
  const sign = cents < 0 ? "-" : "";
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  const dollarsStr = dollars.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return sign + "$" + dollarsStr + "." + (rem < 10 ? "0" + rem : "" + rem);
}
