# We cut our deploy from 40 minutes to 6

Last March our deploy took 40 minutes. Nobody trusted it, so nobody shipped on Fridays, and a lot of Tuesdays turned into a queue of people waiting for the one person who understood the pipeline. That person was Priya, and she was tired of being the pipeline.

We did not rewrite anything. We spent two weeks reading the build logs line by line, and the picture was dull. Of the 40 minutes, 31 were spent downloading the same dependencies we had downloaded the day before. We were paying our CI provider $1,900 a month to fetch left-pad-sized things over and over.

So we added three caches: one for the package manager, one for the compiled assets, one for the Docker layers. That was the whole project. The first cached run took 14 minutes, which felt like a miracle until we noticed the Docker cache was being invalidated by a timestamp in a build file. Fixing that took Priya one afternoon and a very small diff.

After that the deploy took 6 minutes. The monthly bill dropped to $620. The Friday rule is gone. We just deploy.

What I took from it is that the slow part is rarely the part you suspect. We had a long list of clever ideas: parallel test shards, a faster runner, a new orchestrator. Every one of them would have been a bigger project than the three caches, and none of them would have touched the 31 minutes. Read the logs first. It is boring and it works.
